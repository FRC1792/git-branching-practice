# Conflict Challenge — Resolve a Merge Conflict

1. Create a branch:
   git checkout -b conflict-yourname

2. Edit conflicts/story.txt and replace the ending.

3. Commit and push your branch.

4. Open a Pull Request into main.

You will likely encounter a merge conflict. Resolve it locally,
commit the fix, and push again.
