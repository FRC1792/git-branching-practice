# Activity 2 — Collaborate on a Feature Branch

1. Create or checkout a shared branch:
   git checkout -b feature-class-project

2. Edit shared/class-roster.md

3. Add your name to the list.

4. Commit, push, and open a Pull Request into the shared branch.
