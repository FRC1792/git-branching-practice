# Activity 1 — Create Your Own Branch

1. Create a branch:
   git checkout -b feature-yourname-profile

2. Create a folder under students/ with your name.

3. Add a profile.md file with info about yourself.

4. Commit and push your branch.

5. Open a Pull Request into main.
